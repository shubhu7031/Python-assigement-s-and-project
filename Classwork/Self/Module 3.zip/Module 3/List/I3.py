def check_list_is_empty(lst):
    if not lst:
        print("List is Empty")
    else:
        print("List is not Empty")
        
check_list_is_empty([])
check_list_is_empty([1,2])