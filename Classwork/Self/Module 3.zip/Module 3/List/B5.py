a = [12,10,22,54,2,43,83,33,88,31,44]

min = min(a)
max = max(a)

sum = min + max

print(sum)