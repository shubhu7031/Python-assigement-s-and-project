lst = ['g', 'o', 'p', 'a', 'n']

nlst = ''.join(lst)
print(nlst)