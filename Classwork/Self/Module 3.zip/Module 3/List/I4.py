def common(lst1, lst2):
    for x in lst1 and lst2:
        if x in lst1 and lst2:
            y = True
    if y == True:
        print(True)
        
common([12,11,23,11], [12,22,23,1,3])