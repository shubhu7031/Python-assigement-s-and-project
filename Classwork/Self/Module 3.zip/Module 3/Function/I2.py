def var():
    a = "hello"
    b = 12
    c = 1.23
    
print(var.__code__.co_nlocals)