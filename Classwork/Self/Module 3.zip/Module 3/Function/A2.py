str1 = "gopan"
print(str1[::-1])
