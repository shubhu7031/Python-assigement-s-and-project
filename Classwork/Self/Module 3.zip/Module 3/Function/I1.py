def add(a, b):
    sum = a+b
    print(sum)


def sub(a, b):
    sub = a-b
    print(sub)


def add_sub():
    add(2, 3)
    sub(4, 2)


add_sub()