t = 2, 4, 5, 6, 2, 3, 4, 4, 7 
print(t)
c = t.count(4)
print(c)
