t = ("Hello", 12, 22.2, True)

print(t)
