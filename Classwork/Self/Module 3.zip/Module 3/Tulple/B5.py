t = "Apple", "Orange", 32, "Mango", 23.2

print("Apple" in t)
print("Gopan" in t)
