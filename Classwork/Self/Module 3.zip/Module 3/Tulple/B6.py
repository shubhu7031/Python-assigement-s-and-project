t = 12,32,12,4,21,4,157
print(t)
t = list(t)
print(t)