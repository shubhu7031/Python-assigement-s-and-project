t = 1,2,32,12,23,123
print(len(t))