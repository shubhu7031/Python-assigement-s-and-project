t = [("a",1),("b",4),("c",7)]
d = dict(t)
print(d)