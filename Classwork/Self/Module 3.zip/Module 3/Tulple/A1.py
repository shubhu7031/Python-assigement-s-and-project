L = [(),('a', 'b'), ('a', 'b', 'c')]

L = [t for t in L if t]
print(L)