t = (55,42,32,1,76,5,99,7,52)
t1 = reversed(t)
print(tuple(t1))