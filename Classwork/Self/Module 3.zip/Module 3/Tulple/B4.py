t1 = "g","o","p","a","n"," ","d","i","w","a","n"
t2 = ''.join(t1)
print(t2)