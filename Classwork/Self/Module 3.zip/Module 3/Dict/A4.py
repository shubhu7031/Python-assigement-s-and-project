str1 = 'Gopan'
t = {}
for x in str1:
    t[x]=str1.count(x)
print(t)