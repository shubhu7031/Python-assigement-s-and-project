d = {1:32}
key = d.keys()
print(int(key))

for x in key:
    if x in key > 1:
        print("Multiple Key don't Exist")
    else:
        print("Multiple Key Exist")
