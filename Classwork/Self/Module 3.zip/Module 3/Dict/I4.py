t1 = ['a','b','c']
t2 = [1,2,3]
zib = zip(t1,t2)
print(dict(zib))