d = {"a":10,"b":2,"c":22,"d":4}
lst = list(d.values())
lst.sort()
print(lst[-3:])

