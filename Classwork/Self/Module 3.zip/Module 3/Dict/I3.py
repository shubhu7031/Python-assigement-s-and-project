d1 = {"a":1,"b":3}
d2 = {"c":3,"d":4}
d2.update(d1)
print(d2)