p = int(input("Enter Principal: "))
r = int(input("Enter Rate of Interest: "))
t = int(input("Enter Number of Years: "))

si = (p*r*t)/100

print("The Simple Interest is: ",si)