n = int(input("Enter a Number:"))

if (n % 2) == 0:
    print("Your Number is Even")
else:
    print("Your Number is Odd")