a = int(input("Enter First Value:"))
b = int(input("Enter Second Value:"))
sum = a+b
diff = a-b


if a == b:
    print(True)
elif sum == 5 or diff == 5:
    print(True)
else:
    print(False)