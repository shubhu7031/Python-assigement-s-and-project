num = int(input("Enter any Number: "))

if num > 0:
    print("Your Number is positive")
elif num == 0:
    print("Your Number is zero")
else:
    print("Your Number is Negative")
