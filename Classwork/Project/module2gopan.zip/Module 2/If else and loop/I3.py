# Area of triangle

# h = int(input("Enter Height of Triangle:"))
# b = int(input("Enter Base of Triangle:"))

# area = (h*b)/2

# print("Area of Triangle is:", area)

# Area of Circle

r = int(input("Enter Radius of Circle:"))

area = (r*r*22)/7

print("Area of Circle is:",area)