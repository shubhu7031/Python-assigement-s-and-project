a = [2,3,1]
a.sort()
print(a)