from platform import python_version

print("Current version of python :", python_version())
