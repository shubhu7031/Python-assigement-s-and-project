n = int(input("Enter a integer:"))

sum = (n*(n+1))/2

print(sum)