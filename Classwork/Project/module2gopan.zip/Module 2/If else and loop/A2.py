n = int(input("Enter an Integer:"))

t = str(n)
t1 = t + t
t2 = t + t + t

a = n + int(t1) + int(t2)
print(a)