a = input("Enter a string:")
if len(a) % 4 == 0:
    
    print(a[::-1])
else:
    print(a)