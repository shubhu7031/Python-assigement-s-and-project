str = "I am doing python programing"

print(str.count('python'))