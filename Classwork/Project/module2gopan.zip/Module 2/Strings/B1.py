a = input("Enter a string:")

print("Length of your given String is",len(a))