# Online-Fruit-Store
This The Project For Collage intern Mini project Based On Python Flask

// fruit_stole.sql is The Database File ...please Import this File to Your Mysql database And Connect To The Proper Way.

Author : Mitul Patel
From : India,Gujarat
Contact :mitulp236@gmail.com

Thank You !
       
